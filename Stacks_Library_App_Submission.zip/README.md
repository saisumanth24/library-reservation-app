# Stacks — Library Book Reservation App

A library reservation app built with HTML, CSS, JavaScript, React, Bootstrap, Node.js, Express, and MongoDB (through Mongoose).

## Features

- Search books by title, author, ISBN, or category.
- Create a student account, sign in, and reserve/cancel available copies.
- View reservations and in-app alerts.
- Admins can add, edit, and remove books, update copy counts, and cancel active reservations.
- Reservation requests decrement availability atomically to prevent overbooking.

## Run locally

1. Install Node.js 18+ and run `npm install` in the project root, then `npm install --prefix server` and `npm install --prefix client`.
2. Install and start MongoDB, or use a MongoDB connection string you control.
3. Copy `server/.env.example` to `server/.env`; set a private `JWT_SECRET` and your MongoDB connection string. With `SEED_DEMO_DATA=true`, the API adds a small sample catalog when the books collection is empty.
4. To enable the **Add books** admin link, set `ADMIN_NAME`, `ADMIN_EMAIL`, and a private `ADMIN_PASSWORD` (at least 8 characters) in `server/.env`. The server creates this admin on startup, or grants admin access to the existing account with that email. Leave all three blank to skip admin setup. The example file intentionally contains no administrator credentials.
5. Run `npm run dev` from the root.
6. Open `http://localhost:5173`. Sign in as the configured admin to add/manage books; visitors and student accounts can search the collection and reserve available copies.

The API listens on port 5000 by default. Public registration always creates a student account; only configured administrators can add, edit, or remove books.

## Build

Run `npm run build` in the root. The production API is started with `npm start` from the root after setting its environment variables.

## Public deployment

Deploy the repository to Render using `render.yaml`, and create a MongoDB Atlas database for `MONGODB_URI`.
Set `JWT_SECRET`, `CLIENT_ORIGIN`, and the administrator variables in the hosting service. When deployed,
set `NODE_ENV=production`; the server then serves the built React application and API from one HTTPS URL.
The app does not use localhost when that public URL is open.

## Final review checks

- Confirm `http://localhost:5000/api/health` returns `{"status":"ok"}`.
- Register a student account, search for a book, reserve it, and cancel the reservation. Confirm the available copy count and alert update.
- Sign in with the configured administrator account and verify adding, editing, and removing a book.
- Run `npm run build` from the root and resolve any build errors before the review.
