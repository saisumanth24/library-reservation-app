@echo off
setlocal
cd /d "%~dp0"

if not exist "server\.env" (
  echo Creating local server configuration...
  powershell -NoProfile -ExecutionPolicy Bypass -Command "$bytes = New-Object byte[] 48; $rng = [System.Security.Cryptography.RandomNumberGenerator]::Create(); $rng.GetBytes($bytes); $secret = [Convert]::ToBase64String($bytes); $rng.Dispose(); $config = (Get-Content 'server\.env.example' -Raw).Replace('replace-this-with-a-long-random-secret', $secret); [System.IO.File]::WriteAllText((Join-Path (Get-Location) 'server\.env'), $config)"
  if errorlevel 1 goto failed
)

if not exist "node_modules\concurrently\package.json" (
  echo Installing root packages...
  call npm install
  if errorlevel 1 goto failed
)
if not exist "server\node_modules\express\package.json" (
  echo Installing server packages...
  call npm install --prefix server
  if errorlevel 1 goto failed
)
if not exist "client\node_modules\vite\package.json" (
  echo Installing client packages...
  call npm install --prefix client
  if errorlevel 1 goto failed
)

set "FRONTEND_READY=0"
set "API_READY=0"
curl.exe --fail --silent --output NUL --max-time 2 http://127.0.0.1:5173/ >nul 2>&1
if not errorlevel 1 set "FRONTEND_READY=1"
curl.exe --fail --silent --output NUL --max-time 2 http://127.0.0.1:5000/api/health >nul 2>&1
if not errorlevel 1 set "API_READY=1"
if "%FRONTEND_READY%%API_READY%"=="11" goto open
if not "%FRONTEND_READY%%API_READY%"=="00" (
  echo Only one app service is running. Close its existing terminal, then run this file again.
  pause
  exit /b 1
)

echo Starting the library app...
start "Library App Servers" /D "%~dp0" cmd /k "npm run dev"

for /L %%i in (1,1,45) do (
  curl.exe --fail --silent --output NUL --max-time 2 http://127.0.0.1:5173/ >nul 2>&1
  if not errorlevel 1 (
    curl.exe --fail --silent --output NUL --max-time 2 http://127.0.0.1:5000/api/health >nul 2>&1
    if not errorlevel 1 goto open
  )
  timeout /t 1 /nobreak >nul
)

echo The app did not start. Check the "Library App Servers" window and confirm MongoDB is running.
pause
exit /b 1

:open
start "" "http://localhost:5173/"
exit /b 0

:failed
echo Setup failed. Check the message above, then try this file again.
pause
exit /b 1 