import React, { useCallback, useEffect, useMemo, useState } from "react";

const API_URL = import.meta.env.VITE_API_URL || "/api";
const tabs = [
  { id: "search", label: "Discover", icon: "⌕" },
  { id: "reservations", label: "My reservations", icon: "▤" },
  { id: "alerts", label: "Alerts", icon: "♧" },
  { id: "account", label: "Account", icon: "◉" }
];

async function request(path, { token, ...options } = {}) {
  const response = await fetch(`${API_URL}${path}`, {
    ...options,
    headers: {
      "Content-Type": "application/json",
      ...(token ? { Authorization: `Bearer ${token}` } : {}),
      ...options?.headers
    }
  });
  const data = response.status === 204 ? null : await response.json();
  if (!response.ok) throw new Error(data?.message || "Something went wrong. Please try again.");
  return data;
}

function App() {
  const [token, setToken] = useState(() => localStorage.getItem("library-token"));
  const [user, setUser] = useState(null);
  const [activeTab, setActiveTab] = useState("search");
  const [query, setQuery] = useState("");
  const [books, setBooks] = useState([]);
  const [adminBooks, setAdminBooks] = useState([]);
  const [reservations, setReservations] = useState([]);
  const [alerts, setAlerts] = useState([]);
  const [busy, setBusy] = useState(false);
  const [message, setMessage] = useState("");
  const [error, setError] = useState("");
  const [authMode, setAuthMode] = useState("login");
  const [authForm, setAuthForm] = useState({ name: "", email: "", password: "" });
  const [bookForm, setBookForm] = useState({ title: "", author: "", isbn: "", category: "", description: "", totalCopies: "1" });
  const [editingBookId, setEditingBookId] = useState(null);

  const notifyError = useCallback((reason) => setError(reason.message || "Request failed."), []);

  const loadBooks = useCallback(async () => {
    try {
      setBooks(await request(`/books${query.trim() ? `?q=${encodeURIComponent(query.trim())}` : ""}`));
    } catch (reason) {
      notifyError(reason);
    }
  }, [notifyError, query]);

  const loadAdminBooks = useCallback(async (currentToken) => {
    if (!currentToken) return;
    try {
      setAdminBooks(await request("/books", { token: currentToken }));
    } catch (reason) {
      notifyError(reason);
    }
  }, [notifyError]);

  const loadMemberData = useCallback(async (currentToken) => {
    if (!currentToken) return;
    try {
      const [profile, memberReservations, memberAlerts] = await Promise.all([
        request("/auth/me", { token: currentToken }),
        request("/reservations", { token: currentToken }),
        request("/alerts", { token: currentToken })
      ]);
      setUser(profile);
      setReservations(memberReservations);
      setAlerts(memberAlerts);
    } catch (reason) {
      if (reason.message.includes("session") || reason.message.includes("Account not found")) {
        localStorage.removeItem("library-token");
        setToken(null);
        setUser(null);
      } else {
        notifyError(reason);
      }
    }
  }, [notifyError]);

  useEffect(() => {
    const timer = window.setTimeout(loadBooks, query.trim() ? 180 : 0);
    return () => window.clearTimeout(timer);
  }, [loadBooks, query]);
  useEffect(() => { loadMemberData(token); }, [loadMemberData, token]);
  useEffect(() => {
    if (user?.role === "admin") loadAdminBooks(token);
    else setAdminBooks([]);
  }, [loadAdminBooks, token, user?.role]);

  const activeReservations = useMemo(
    () => reservations.filter((reservation) => reservation.status === "reserved"),
    [reservations]
  );
  const unreadCount = alerts.filter((alert) => !alert.read).length;

  async function submitAuth(event) {
    event.preventDefault();
    setBusy(true);
    setError("");
    try {
      const endpoint = authMode === "login" ? "/auth/login" : "/auth/register";
      const result = await request(endpoint, { method: "POST", body: JSON.stringify(authForm) });
      localStorage.setItem("library-token", result.token);
      setToken(result.token);
      setUser(result.user);
      setAuthForm({ name: "", email: "", password: "" });
      setMessage(`Welcome${result.user.name ? `, ${result.user.name.split(" ")[0]}` : ""}.`);
    } catch (reason) {
      notifyError(reason);
    } finally {
      setBusy(false);
    }
  }

  async function reserveBook(book) {
    if (!token) {
      setActiveTab("account");
      setError("Sign in or create an account to reserve a book.");
      return;
    }
    setBusy(true);
    setError("");
    try {
      const result = await request("/reservations", { token, method: "POST", body: JSON.stringify({ bookId: book._id }) });
      setMessage(`"${book.title}" is reserved for you.`);
      if (result.warning) setError(result.warning);
      await Promise.all([loadBooks(), loadMemberData(token)]);
    } catch (reason) {
      notifyError(reason);
    } finally {
      setBusy(false);
    }
  }

  async function cancelReservation(reservation) {
    setBusy(true);
    setError("");
    try {
      const result = await request(`/reservations/${reservation._id}/cancel`, { token, method: "PATCH" });
      setMessage("Reservation cancelled.");
      if (result.warning) setError(result.warning);
      await Promise.all([loadBooks(), loadMemberData(token)]);
    } catch (reason) {
      notifyError(reason);
    } finally {
      setBusy(false);
    }
  }

  async function addBook(event) {
    event.preventDefault();
    setBusy(true);
    setError("");
    try {
      const payload = { ...bookForm, totalCopies: Number(bookForm.totalCopies) };
      if (editingBookId) {
        await request(`/books/${editingBookId}`, { token, method: "PATCH", body: JSON.stringify(payload) });
        setMessage("Book details updated.");
      } else {
        await request("/books", { token, method: "POST", body: JSON.stringify(payload) });
        setMessage("Book added to the collection.");
      }
      resetBookForm();
      await Promise.all([loadBooks(), loadAdminBooks(token)]);
    } catch (reason) {
      notifyError(reason);
    } finally {
      setBusy(false);
    }
  }

  function resetBookForm() {
    setBookForm({ title: "", author: "", isbn: "", category: "", description: "", totalCopies: "1" });
    setEditingBookId(null);
  }

  function editBook(book) {
    setBookForm({
      title: book.title,
      author: book.author,
      isbn: book.isbn || "",
      category: book.category || "",
      description: book.description || "",
      totalCopies: String(book.totalCopies)
    });
    setEditingBookId(book._id);
    setError("");
    setMessage("");
  }

  async function removeBook(book) {
    if (!window.confirm(`Remove "${book.title}" from the collection?`)) return;
    setBusy(true);
    setError("");
    try {
      await request(`/books/${book._id}`, { token, method: "DELETE" });
      if (editingBookId === book._id) resetBookForm();
      setMessage("Book removed from the collection.");
      await Promise.all([loadBooks(), loadAdminBooks(token)]);
    } catch (reason) {
      notifyError(reason);
    } finally {
      setBusy(false);
    }
  }

  async function markAlertsRead() {
    try {
      await request("/alerts/read-all", { token, method: "PATCH" });
      await loadMemberData(token);
    } catch (reason) {
      notifyError(reason);
    }
  }

  function signOut() {
    localStorage.removeItem("library-token");
    setToken(null);
    setUser(null);
    setReservations([]);
    setAlerts([]);
    setActiveTab("search");
    setMessage("You have been signed out.");
  }

  function updateAuth(field, value) {
    setAuthForm((current) => ({ ...current, [field]: value }));
  }

  return (
    <div className="app-shell">
      <header className="topbar">
        <a className="brand" href="#" onClick={() => setActiveTab("search")} aria-label="Stacks home">
          <span className="brand-mark">s.</span><span>stacks<span className="brand-period">.</span></span>
        </a>
        <div className="topbar-right">
          <span className="topbar-note">Your campus library, made simple</span>
          {user && <button className="profile-chip" onClick={() => setActiveTab("account")}><span className="avatar">{user.name[0]}</span>{user.name.split(" ")[0]}</button>}
        </div>
      </header>

      <main className="page-wrap">
        <section className="welcome-row">
          <div>
            <p className="eyebrow">{new Date().toLocaleDateString(undefined, { weekday: "long", month: "long", day: "numeric" })}</p>
            <h1>{activeTab === "search" ? <>Find your next<br /><em>great read.</em></> : activeTab === "admin" ? "Add books" : tabs.find((tab) => tab.id === activeTab)?.label}</h1>
            <p className="intro">{activeTab === "search" ? "Search the shelves, save your spot, and spend less time waiting." : "Everything you need for a smoother library visit."}</p>
          </div>
          <div className="welcome-art" aria-hidden="true"><div className="sun"></div><div className="book-stack stack-one"></div><div className="book-stack stack-two"></div><div className="book-stack stack-three"></div><span className="art-sparkle">✳</span></div>
        </section>

        <nav className="tabs" aria-label="Main navigation">
          {tabs.filter((tab) => tab.id !== "alerts" || user).map((tab) => (
            <button key={tab.id} className={`tab ${activeTab === tab.id ? "active" : ""}`} onClick={() => { setActiveTab(tab.id); setError(""); setMessage(""); }}>
              <span className="tab-icon">{tab.icon}</span>{tab.label}
              {tab.id === "reservations" && activeReservations.length > 0 && <span className="count-badge">{activeReservations.length}</span>}
              {tab.id === "alerts" && unreadCount > 0 && <span className="count-badge">{unreadCount}</span>}
            </button>
          ))}
          <button className={`tab admin-tab ${activeTab === "admin" ? "active" : ""}`} onClick={() => { setActiveTab("admin"); setError(""); setMessage(""); }}><span className="tab-icon">＋</span>Add books</button>
        </nav>

        {error && <div className="notice error-notice" role="alert"><span>!</span>{error}<button onClick={() => setError("")} aria-label="Dismiss error">×</button></div>}
        {message && <div className="notice success-notice" role="status"><span>✓</span>{message}<button onClick={() => setMessage("")} aria-label="Dismiss message">×</button></div>}

        {activeTab === "search" && <section className="content-section">
          <div className="section-heading">
            <div><p className="eyebrow">THE COLLECTION</p><h2>Explore the shelves</h2></div>
            <span className="results-count">{books.length} {books.length === 1 ? "book" : "books"}</span>
          </div>
          <label className="search-box">
            <span className="search-icon">⌕</span>
            <input value={query} onChange={(event) => setQuery(event.target.value)} placeholder="Search title, author, ISBN, or subject..." aria-label="Search books" />
            {query && <button onClick={() => setQuery("")} aria-label="Clear search">×</button>}
            <kbd>⌘ K</kbd>
          </label>
          {books.length === 0 ? <EmptyState title="No books found" text="Try another title or author, or check back later." /> :
            <div className="book-grid">{books.map((book, index) => <BookCard key={book._id} book={book} index={index} onReserve={reserveBook} busy={busy} />)}</div>}
        </section>}

        {activeTab === "reservations" && <section className="content-section">
          {!user ? <EmptyState title="Sign in to see your reservations" text="Your saved books and current reservations will show up here." action={() => setActiveTab("account")} actionLabel="Go to account" /> :
            reservations.length === 0 ? <EmptyState title="Your shelf is waiting" text="Reserve a book from the collection and it will appear here." action={() => setActiveTab("search")} actionLabel="Browse books" /> :
              <div className="reservation-list">{reservations.map((item) => <article className="reservation-row" key={item._id}>
                <BookCover book={item.book} index={1} compact />
                <div className="reservation-info"><span className="eyebrow">{item.book?.category || "COLLECTION"}</span><h3>{item.book?.title || "Book no longer listed"}</h3><p>{item.book?.author || ""} <span>·</span> Reserved {new Date(item.reservedAt).toLocaleDateString()}</p></div>
                <span className={`status-pill ${item.status}`}>{item.status === "reserved" ? "Ready for pickup" : "Cancelled"}</span>
                {item.status === "reserved" && <button className="text-button" disabled={busy} onClick={() => cancelReservation(item)}>Cancel</button>}
              </article>)}</div>}
        </section>}

        {activeTab === "alerts" && <section className="content-section">
          <div className="section-heading"><div><p className="eyebrow">UPDATES</p><h2>Your alerts</h2></div>{unreadCount > 0 && <button className="text-button" onClick={markAlertsRead}>Mark all as read</button>}</div>
          {alerts.length === 0 ? <EmptyState title="All caught up" text="Reservation updates and library notices will appear here." /> :
            <div className="alert-list">{alerts.map((alert) => <article className={`alert-row ${alert.read ? "" : "unread"}`} key={alert._id}><span className="alert-icon">{alert.message.includes("cancelled") ? "↗" : "✓"}</span><div><p>{alert.message}</p><time>{new Date(alert.createdAt).toLocaleString()}</time></div>{!alert.read && <span className="unread-dot" aria-label="Unread"></span>}</article>)}</div>}
        </section>}

        {activeTab === "account" && <section className="content-section account-section">
          {user ? <div className="account-card">
            <div className="account-avatar">{user.name[0]}</div><p className="eyebrow">YOUR ACCOUNT</p><h2>{user.name}</h2><p className="account-email">{user.email}</p>
            <div className="account-stats"><div><strong>{activeReservations.length}</strong><span>Active reservations</span></div><div><strong>{unreadCount}</strong><span>Unread alerts</span></div></div>
            <button className="btn btn-outline-dark signout-button" onClick={signOut}>Sign out</button>
          </div> : <form className="auth-card" onSubmit={submitAuth}>
            <p className="eyebrow">MEMBER ACCESS</p><h2>{authMode === "login" ? "Welcome back." : "Join your library."}</h2>
            <p className="auth-intro">{authMode === "login" ? "Sign in to manage your reservations." : "Create an account to reserve books and get updates."}</p>
            {authMode === "register" && <label className="form-label">Full name<input required minLength="2" className="form-control" value={authForm.name} onChange={(event) => updateAuth("name", event.target.value)} placeholder="Your name" /></label>}
            <label className="form-label">Email address<input required type="email" className="form-control" value={authForm.email} onChange={(event) => updateAuth("email", event.target.value)} placeholder="you@school.edu" /></label>
            <label className="form-label">Password<input required minLength="8" type="password" className="form-control" value={authForm.password} onChange={(event) => updateAuth("password", event.target.value)} placeholder="At least 8 characters" /></label>
            <button className="btn btn-dark w-100 submit-button" disabled={busy}>{busy ? "Please wait..." : authMode === "login" ? "Sign in" : "Create account"}<span>→</span></button>
            <p className="auth-switch">{authMode === "login" ? "New to Stacks?" : "Already have an account?"} <button type="button" onClick={() => { setAuthMode(authMode === "login" ? "register" : "login"); setError(""); }}>{authMode === "login" ? "Create an account" : "Sign in"}</button></p>
          </form>}
        </section>}

        {activeTab === "admin" && user?.role !== "admin" && <section className="content-section">
          <EmptyState title="Admin access required" text="Sign in with an administrator account to add books. Configure an admin account in server/.env if you have not set one up yet." action={() => setActiveTab("account")} actionLabel="Go to account" />
        </section>}

        {activeTab === "admin" && user?.role === "admin" && <section className="content-section">
          <div className="section-heading"><div><p className="eyebrow">LIBRARY MANAGEMENT</p><h2>Admin panel</h2></div></div>
          <div className="admin-layout">
            <form className="admin-form" onSubmit={addBook}><h3>{editingBookId ? "Update book" : "Add a book"}</h3><p>{editingBookId ? "Update the catalog details and copy count." : "Make a new title available in the collection."}</p>
              <label className="form-label">Title<input required className="form-control" value={bookForm.title} onChange={(event) => setBookForm({ ...bookForm, title: event.target.value })} /></label>
              <label className="form-label">Author<input required className="form-control" value={bookForm.author} onChange={(event) => setBookForm({ ...bookForm, author: event.target.value })} /></label>
              <label className="form-label">ISBN<input className="form-control" value={bookForm.isbn} onChange={(event) => setBookForm({ ...bookForm, isbn: event.target.value })} /></label>
              <label className="form-label">Category<input className="form-control" value={bookForm.category} onChange={(event) => setBookForm({ ...bookForm, category: event.target.value })} placeholder="e.g. Science" /></label>
              <label className="form-label">Description<textarea className="form-control" rows="3" value={bookForm.description} onChange={(event) => setBookForm({ ...bookForm, description: event.target.value })} /></label>
              <label className="form-label">Total copies<input required min="0" step="1" type="number" className="form-control" value={bookForm.totalCopies} onChange={(event) => setBookForm({ ...bookForm, totalCopies: event.target.value })} /></label>
              <div className="admin-form-actions"><button className="btn btn-dark submit-button" disabled={busy}>{editingBookId ? "Save changes" : "Add to collection"} <span>→</span></button>{editingBookId && <button type="button" className="btn btn-outline-dark" disabled={busy} onClick={resetBookForm}>Cancel</button>}</div>
            </form>
            <div className="admin-overview"><div className="admin-stat"><span>BOOK TITLES</span><strong>{adminBooks.length}</strong></div><div className="admin-stat"><span>ACTIVE RESERVATIONS</span><strong>{reservations.filter((item) => item.status === "reserved").length}</strong></div><h3>Manage reservations</h3>
              {reservations.length === 0 ? <p className="muted-copy">No reservations yet.</p> : reservations.map((item) => <div className="admin-reservation" key={item._id}><span><strong>{item.book?.title || "Removed book"}</strong><small>{item.user?.name} · {item.user?.email}</small></span><span className={`status-pill ${item.status}`}>{item.status}</span>{item.status === "reserved" && <button className="text-button" disabled={busy} onClick={() => cancelReservation(item)}>Cancel</button>}</div>)}
            </div>
          </div>
          <div className="admin-catalog"><div className="section-heading"><div><p className="eyebrow">COLLECTION</p><h2>Manage books</h2></div><span className="results-count">{adminBooks.length} {adminBooks.length === 1 ? "book" : "books"}</span></div>
            {adminBooks.length === 0 ? <EmptyState title="No books in the collection" text="Add a book using the form above." /> :
              <div className="admin-book-list">{adminBooks.map((book) => <article className="admin-book-row" key={book._id}>
                <div><strong>{book.title}</strong><span>{book.author} · {book.category || "General"}</span></div>
                <span className="admin-book-copies">{book.availableCopies} / {book.totalCopies} available</span>
                <div className="admin-book-actions"><button className="text-button" disabled={busy} onClick={() => editBook(book)}>Edit</button><button className="text-button danger-text" disabled={busy} onClick={() => removeBook(book)}>Remove</button></div>
              </article>)}</div>}
          </div>
        </section>}
      </main>
      <footer className="footer"><span>stacks<span className="brand-period">.</span></span><span>Find a book. Find your focus.</span></footer>
    </div>
  );
}

function BookCard({ book, index, onReserve, busy }) {
  return <article className="book-card">
    <BookCover book={book} index={index} />
    <div className="book-details"><div className="book-category">{book.category || "GENERAL"}</div><h3>{book.title}</h3><p className="book-author">by {book.author}</p>
      {book.description && <p className="book-description">{book.description}</p>}
      <div className="book-card-bottom"><span className={`availability ${book.availableCopies ? "" : "unavailable"}`}><i></i>{book.availableCopies ? `${book.availableCopies} available` : "Currently unavailable"}</span>
        <button className="reserve-button" disabled={!book.availableCopies || busy} onClick={() => onReserve(book)}>{book.availableCopies ? "Reserve" : "Waitlist"}<span>↗</span></button>
      </div>
    </div>
  </article>;
}

function BookCover({ book, index, compact = false }) {
  const palettes = ["sage", "ochre", "rose", "blue", "moss", "plum"];
  return <div className={`book-cover ${palettes[index % palettes.length]} ${compact ? "compact" : ""}`} aria-hidden="true">
    <span className="cover-top">STACKS LIBRARY</span><span className="cover-decoration">{["✳", "◒", "⌁", "✦", "◉", "❋"][index % 6]}</span><span className="cover-title">{book?.title}</span><span className="cover-author">{book?.author}</span>
  </div>;
}

function EmptyState({ title, text, action, actionLabel }) {
  return <div className="empty-state"><div className="empty-icon">✳</div><h3>{title}</h3><p>{text}</p>{action && <button className="btn btn-dark" onClick={action}>{actionLabel} →</button>}</div>;
}

export default App;
