const mongoose = require("mongoose");

const userSchema = new mongoose.Schema(
  {
    name: { type: String, required: true, trim: true },
    email: { type: String, required: true, unique: true, lowercase: true, trim: true },
    passwordHash: { type: String, required: true },
    role: { type: String, enum: ["student", "admin"], default: "student" }
  },
  { timestamps: true }
);

const bookSchema = new mongoose.Schema(
  {
    title: { type: String, required: true, trim: true },
    author: { type: String, required: true, trim: true },
    isbn: { type: String, default: "", trim: true },
    category: { type: String, default: "General", trim: true },
    description: { type: String, default: "" },
    totalCopies: { type: Number, required: true, min: 0 },
    availableCopies: { type: Number, required: true, min: 0 }
  },
  { timestamps: true }
);

const reservationSchema = new mongoose.Schema(
  {
    user: { type: mongoose.Schema.Types.ObjectId, ref: "User", required: true },
    book: { type: mongoose.Schema.Types.ObjectId, ref: "Book", required: true },
    status: { type: String, enum: ["reserved", "cancelled"], default: "reserved" },
    reservedAt: { type: Date, default: Date.now }
  },
  { timestamps: true }
);

const alertSchema = new mongoose.Schema(
  {
    user: { type: mongoose.Schema.Types.ObjectId, ref: "User", required: true },
    message: { type: String, required: true },
    read: { type: Boolean, default: false }
  },
  { timestamps: true }
);

module.exports = {
  User: mongoose.model("User", userSchema),
  Book: mongoose.model("Book", bookSchema),
  Reservation: mongoose.model("Reservation", reservationSchema),
  Alert: mongoose.model("Alert", alertSchema)
};
