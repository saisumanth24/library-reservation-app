require("dotenv").config();

const express = require("express");
const cors = require("cors");
const mongoose = require("mongoose");
const bcrypt = require("bcryptjs");
const jwt = require("jsonwebtoken");
const path = require("path");
const { User, Book, Reservation, Alert } = require("./models");

const app = express();
app.use(cors({
  origin: process.env.NODE_ENV === "production"
    ? process.env.CLIENT_ORIGIN || true
    : process.env.CLIENT_ORIGIN || "http://localhost:5173"
}));
app.use(express.json());

function authenticate(req, res, next) {
  const token = req.headers.authorization?.replace(/^Bearer\s+/i, "");
  if (!token) return res.status(401).json({ message: "Please sign in to continue." });
  try {
    req.user = jwt.verify(token, process.env.JWT_SECRET);
    return next();
  } catch {
    return res.status(401).json({ message: "Your session has expired. Please sign in again." });
  }
}

function adminOnly(req, res, next) {
  if (req.user.role !== "admin") return res.status(403).json({ message: "Administrator access required." });
  return next();
}

function signToken(user) {
  return jwt.sign({ id: user.id, name: user.name, email: user.email, role: user.role }, process.env.JWT_SECRET, { expiresIn: "7d" });
}

async function configureAdminAccount() {
  const { ADMIN_NAME, ADMIN_EMAIL, ADMIN_PASSWORD } = process.env;
  const adminValues = [ADMIN_NAME, ADMIN_EMAIL, ADMIN_PASSWORD];
  if (adminValues.every((value) => !value)) return;
  if (!ADMIN_NAME?.trim() || !ADMIN_EMAIL?.trim() || !ADMIN_PASSWORD || ADMIN_PASSWORD.trim().length < 8) {
    throw new Error("Set ADMIN_NAME, ADMIN_EMAIL, and an ADMIN_PASSWORD of at least 8 characters together.");
  }

  const email = ADMIN_EMAIL.trim().toLowerCase();
  let user = await User.findOne({ email });
  if (!user) {
    user = await User.create({
      name: ADMIN_NAME.trim(),
      email,
      passwordHash: await bcrypt.hash(ADMIN_PASSWORD, 12),
      role: "admin"
    });
  } else if (user.role !== "admin") {
    user.role = "admin";
    await user.save();
  }
  console.log(`Administrator account ready for ${email}.`);
}

app.get("/api/health", (_req, res) => res.json({ status: "ok" }));

app.post("/api/auth/register", async (req, res, next) => {
  try {
    const { name, email, password } = req.body;
    if (!name?.trim() || !email?.trim() || !password || password.length < 8) {
      return res.status(400).json({ message: "Name, email, and a password of at least 8 characters are required." });
    }
    const normalizedEmail = email.trim().toLowerCase();
    if (await User.exists({ email: normalizedEmail })) return res.status(409).json({ message: "An account with this email already exists." });
    const user = await User.create({
      name: name.trim(),
      email: normalizedEmail,
      passwordHash: await bcrypt.hash(password, 12)
    });
    return res.status(201).json({ token: signToken(user), user: { id: user.id, name: user.name, email: user.email, role: user.role } });
  } catch (error) {
    return next(error);
  }
});

app.post("/api/auth/login", async (req, res, next) => {
  try {
    const user = await User.findOne({ email: req.body.email?.trim().toLowerCase() });
    if (!user || !(await bcrypt.compare(req.body.password || "", user.passwordHash))) {
      return res.status(401).json({ message: "Email or password is incorrect." });
    }
    return res.json({ token: signToken(user), user: { id: user.id, name: user.name, email: user.email, role: user.role } });
  } catch (error) {
    return next(error);
  }
});

app.get("/api/auth/me", authenticate, async (req, res, next) => {
  try {
    const user = await User.findById(req.user.id).select("name email role");
    if (!user) return res.status(401).json({ message: "Account not found." });
    return res.json({ id: user.id, name: user.name, email: user.email, role: user.role });
  } catch (error) {
    return next(error);
  }
});

app.get("/api/books", async (req, res, next) => {
  try {
    const filter = {};
    if (req.query.q) {
      const pattern = new RegExp(String(req.query.q).replace(/[.*+?^${}()|[\]\\]/g, "\\$&"), "i");
      filter.$or = [{ title: pattern }, { author: pattern }, { isbn: pattern }, { category: pattern }];
    }
    if (req.query.available === "true") filter.availableCopies = { $gt: 0 };
    return res.json(await Book.find(filter).sort({ title: 1 }).lean());
  } catch (error) {
    return next(error);
  }
});

app.post("/api/books", authenticate, adminOnly, async (req, res, next) => {
  try {
    const { title, author, isbn, category, description, totalCopies } = req.body;
    if (!title?.trim() || !author?.trim() || !Number.isInteger(totalCopies) || totalCopies < 0) {
      return res.status(400).json({ message: "Title, author, and a non-negative whole number of copies are required." });
    }
    return res.status(201).json(await Book.create({
      title: title.trim(), author: author.trim(), isbn, category, description,
      totalCopies, availableCopies: totalCopies
    }));
  } catch (error) {
    return next(error);
  }
});

app.patch("/api/books/:id", authenticate, adminOnly, async (req, res, next) => {
  try {
    const book = await Book.findById(req.params.id);
    if (!book) return res.status(404).json({ message: "Book not found." });
    const reservedCopies = book.totalCopies - book.availableCopies;
    const { title, author, isbn, category, description, totalCopies } = req.body;
    if (totalCopies !== undefined && (!Number.isInteger(totalCopies) || totalCopies < reservedCopies)) {
      return res.status(400).json({ message: "Total copies cannot be less than the number currently reserved." });
    }
    for (const [key, value] of Object.entries({ title, author, isbn, category, description })) {
      if (value !== undefined) book[key] = value;
    }
    if (totalCopies !== undefined) {
      book.totalCopies = totalCopies;
      book.availableCopies = totalCopies - reservedCopies;
    }
    await book.save();
    return res.json(book);
  } catch (error) {
    return next(error);
  }
});

app.delete("/api/books/:id", authenticate, adminOnly, async (req, res, next) => {
  try {
    const active = await Reservation.exists({ book: req.params.id, status: "reserved" });
    if (active) return res.status(409).json({ message: "Cancel active reservations before removing this book." });
    const book = await Book.findByIdAndDelete(req.params.id);
    if (!book) return res.status(404).json({ message: "Book not found." });
    return res.json({ message: "Book removed." });
  } catch (error) {
    return next(error);
  }
});

app.get("/api/reservations", authenticate, async (req, res, next) => {
  try {
    const filter = req.user.role === "admin" ? {} : { user: req.user.id };
    const reservations = await Reservation.find(filter)
      .populate("book", "title author category")
      .populate("user", "name email")
      .sort({ createdAt: -1 })
      .lean();
    return res.json(reservations);
  } catch (error) {
    return next(error);
  }
});

app.post("/api/reservations", authenticate, async (req, res, next) => {
  try {
    const { bookId } = req.body;
    const book = await Book.findOneAndUpdate(
      { _id: bookId, availableCopies: { $gt: 0 } },
      { $inc: { availableCopies: -1 } },
      { new: true }
    );
    if (!book) return res.status(409).json({ message: "This book is unavailable. Try another copy or check back later." });
    let reservation;
    try {
      reservation = await Reservation.create({ user: req.user.id, book: book.id });
    } catch (error) {
      await Book.updateOne({ _id: book.id }, { $inc: { availableCopies: 1 } });
      throw error;
    }
    let warning = null;
    try {
      await Alert.create({ user: req.user.id, message: `Your reservation for "${book.title}" is confirmed.` });
    } catch (error) {
      console.error("Reservation succeeded, but its alert could not be created.", error);
      warning = "Reservation saved, but its alert could not be created.";
    }
    return res.status(201).json({
      reservation: await reservation.populate("book", "title author category"),
      warning
    });
  } catch (error) {
    return next(error);
  }
});

app.patch("/api/reservations/:id/cancel", authenticate, async (req, res, next) => {
  try {
    const filter = { _id: req.params.id, status: "reserved" };
    if (req.user.role !== "admin") filter.user = req.user.id;
    const reservation = await Reservation.findOneAndUpdate(filter, { status: "cancelled" }, { new: true }).populate("book", "title");
    if (!reservation) return res.status(404).json({ message: "Active reservation not found." });
    try {
      const inventoryUpdate = await Book.updateOne({ _id: reservation.book.id }, { $inc: { availableCopies: 1 } });
      if (inventoryUpdate.matchedCount !== 1) throw new Error("Reserved book was not found while restoring availability.");
    } catch (error) {
      await Reservation.updateOne({ _id: reservation.id, status: "cancelled" }, { status: "reserved" });
      throw error;
    }
    let warning = null;
    try {
      await Alert.create({ user: reservation.user, message: `Your reservation for "${reservation.book.title}" was cancelled.` });
    } catch (error) {
      console.error("Cancellation succeeded, but its alert could not be created.", error);
      warning = "Reservation cancelled, but its alert could not be created.";
    }
    return res.json({ reservation, warning });
  } catch (error) {
    return next(error);
  }
});

app.get("/api/alerts", authenticate, async (req, res, next) => {
  try {
    return res.json(await Alert.find({ user: req.user.id }).sort({ createdAt: -1 }).lean());
  } catch (error) {
    return next(error);
  }
});

app.patch("/api/alerts/read-all", authenticate, async (req, res, next) => {
  try {
    await Alert.updateMany({ user: req.user.id, read: false }, { read: true });
    return res.json({ message: "Alerts marked as read." });
  } catch (error) {
    return next(error);
  }
});

app.use((error, _req, res, _next) => {
  console.error(error);
  if (error.name === "CastError") return res.status(400).json({ message: "Invalid resource identifier." });
  if (error.code === 11000) return res.status(409).json({ message: "This record already exists." });
  return res.status(500).json({ message: "The server could not complete the request." });
});

if (process.env.NODE_ENV === "production") {
  const clientDist = path.join(__dirname, "../../client/dist");
  app.use(express.static(clientDist));
  app.get("*", (_req, res) => res.sendFile(path.join(clientDist, "index.html")));
}

const port = process.env.PORT || 5000;
if (!process.env.JWT_SECRET) throw new Error("JWT_SECRET must be set in the environment.");
mongoose.connect(process.env.MONGODB_URI || "mongodb://127.0.0.1:27017/library_reservations")
  .then(async () => {
    await configureAdminAccount();
    if (process.env.SEED_DEMO_DATA === "true" && await Book.countDocuments() === 0) {
      await Book.insertMany([
        {
          title: "The Quiet Observatory",
          author: "Mira Ellery",
          category: "Science",
          description: "A welcoming introduction to the night sky and the questions it invites.",
          totalCopies: 3,
          availableCopies: 3
        },
        {
          title: "Notes from a Small Garden",
          author: "Imani Wells",
          category: "Nature",
          description: "Seasonal ideas for growing a thoughtful, resilient garden.",
          totalCopies: 2,
          availableCopies: 2
        },
        {
          title: "Maps of Hidden Rivers",
          author: "Arun Bell",
          category: "Fiction",
          description: "A quiet story about memory, place, and the paths between them.",
          totalCopies: 2,
          availableCopies: 2
        },
        {
          title: "The Shape of Questions",
          author: "Lena Park",
          category: "Philosophy",
          description: "A concise guide to clear thinking and asking better questions.",
          totalCopies: 2,
          availableCopies: 2
        },
        {
          title: "Practical Astronomy",
          author: "Noah Mercer",
          category: "Science",
          description: "Hands-on observations and simple projects for curious readers.",
          totalCopies: 1,
          availableCopies: 1
        },
        {
          title: "Designing Everyday Spaces",
          author: "Talia Finch",
          category: "Design",
          description: "Small design principles for making shared spaces work better.",
          totalCopies: 3,
          availableCopies: 3
        }
      ]);
      console.log("Loaded the demo book catalog.");
    }
    app.listen(port, () => console.log(`Library API listening on port ${port}`));
  })
  .catch((error) => {
    console.error("Could not connect to MongoDB.", error);
    process.exitCode = 1;
  });
